#!/bin/sh
#
# Choose nearest stratum:
#	stratum-ru.rplant.xyz   /Moscow/
#	stratum-eu.rplant.xyz   /London/
#	stratum-asia.rplant.xyz /Singapore/
#
while [ 1 ]; do
./cpuminer-sse42 -a power2b -o stratum+tcp://stratum-ru.rplant.xyz:7022 -u BmFNCMPHoxBQUJmF5p4nvKt4LhDgSHK9zp.11
done